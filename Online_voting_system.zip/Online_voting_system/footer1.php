	  <hr>

      <footer>
        <div class="foot_center2"><p>Copyright &copy; mbes college of engineering ambajogai</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbspProgrammed by: vaibhav </p>
		</div>
      </footer>