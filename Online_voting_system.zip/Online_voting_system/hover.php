
	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#help').qtip({
			content: 'click here to view Help',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>


	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.UserName_hover').qtip({
			content: 'Enter your username please',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
	
	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Password_hover').qtip({
			content: 'Enter your Password please',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
 
	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Button_Login_Hover').qtip({
			content: 'Click Here To Login',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
		
		<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.delete_voter').qtip({
			content: 'Click Here To Delete Voter',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
		
		
		<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.btn-danger').qtip({
			content: 'Click here to delete this Voter',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#logout').qtip({
			content: 'Click Here to LogOut',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
			