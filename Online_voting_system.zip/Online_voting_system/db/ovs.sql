-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2025 at 12:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ovs`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `CandidateID` int(11) NOT NULL,
  `abc` varchar(1) NOT NULL,
  `Position` varchar(200) NOT NULL,
  `Party` varchar(100) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  `MiddleName` varchar(100) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Year` varchar(100) NOT NULL,
  `Photo` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`CandidateID`, `abc`, `Position`, `Party`, `FirstName`, `LastName`, `MiddleName`, `Gender`, `Year`, `Photo`) VALUES
(301, 'a', 'Governor', 'Maharashtra Sena', 'adii', 'Lavhrale', '', 'Male', '2nd year', 'upload/IMG_3950.JPG'),
(302, 'a', 'Governor', 'Maharashtra Sena', 'Sneha', 'Deshmukh', 'Sunita', 'Female', '4th year', 'upload/2012-10-13 16.37.13.jpg'),
(303, 'b', 'Vice-Governor', 'Loktantra Morcha', 'Nikhil', 'Kokate', '', 'Male', '3rd year', 'upload/WhatsApp Image 2025-06-24 at 13.41.10_417cd2e1.jpg'),
(401, 'c', '1st Year Representative', 'div B', 'Aarav', 'Patil', 'Ramesh', 'Male', '1st year', 'upload/WhatsApp Image 2025-06-24 at 13.51.18_3d847c84.jpg'),
(402, 'c', '1st Year Representative', 'Div b', 'Sneha', 'Deshmukh', 'Sunita', 'Female', '1st year', 'upload/WhatsApp Image 2025-06-24 at 13.52.02_522a76fa.jpg'),
(403, 'c', '1st Year Representative', 'Navbharat Dal', 'Omkar', 'Sawant', 'Vijay', 'Male', '1st year', 'upload/WhatsApp Image 2025-06-24 at 13.53.27_3a279897.jpg'),
(404, 'c', '1st Year Representative', 'Vikas Sena', 'Prajakta', 'Jadhav', 'Meena', 'Female', '1st year', 'upload/WhatsApp Image 2025-06-24 at 13.55.10_29ab7c8e.jpg'),
(405, 'd', '2nd Year Representative', 'Youth Sena', 'Swapnil', 'Shinde', 'Manoj', 'Male', '2nd year', 'upload/WhatsApp Image 2025-06-24 at 13.51.18_3d847c84.jpg'),
(406, 'd', '2nd Year Representative', 'Lokmanch', 'Tanvi', 'Kadam', 'Sunita', 'Female', '2nd year', 'upload/WhatsApp Image 2025-06-24 at 13.53.27_3a279897.jpg'),
(407, 'd', '2nd Year Representative', 'Navbharat Dal', 'Sachin', 'Naik', 'Mahesh', 'Male', '2nd year', 'upload/WhatsApp Image 2025-06-24 at 13.52.02_522a76fa.jpg'),
(408, 'd', '2nd Year Representative', 'Vikas Sena', 'Riya', 'Pawar', 'Meena', 'Female', '2nd year', 'upload/WhatsApp Image 2025-06-24 at 13.52.53_525526bf.jpg'),
(409, 'e', '3rd Year Representative', 'Youth Sena', 'Kunal', 'Gaikwad', 'Anil', 'Male', '3rd year', 'upload/joneil.jpg'),
(410, 'e', '3rd Year Representative', 'Lokmanch', 'om ', 'Thorat', '', 'Male', '3rd year', 'upload/WhatsApp Image 2025-06-24 at 13.52.53_525526bf.jpg'),
(411, 'e', '3rd Year Representative', 'Navbharat Dal', 'Siddharth', 'Londhe', 'Ramesh', 'Male', '3rd year', 'upload/WhatsApp Image 2025-06-24 at 13.51.18_3d847c84.jpg'),
(412, 'e', '3rd Year Representative', 'Vikas Sena', 'anish', 'Chavan', '', 'Female', '3rd year', 'upload/735e8696-75ef-4b54-ac38-dc1a1249e97d.png'),
(413, 'f', '4th Year Representative', 'Youth Sena', 'Mayur', 'Bhosale', 'Ganesh', 'Male', '4th year', 'upload/WhatsApp Image 2025-06-24 at 13.52.02_522a76fa.jpg'),
(414, 'f', '4th Year Representative', 'Lokmanch', 'Aishwarya', 'Salunkhe', 'Meena', 'Female', '4th year', 'upload/WhatsApp Image 2025-06-24 at 13.52.53_525526bf.jpg'),
(415, 'f', '4th Year Representative', 'Navbharat Dal', 'Yash', 'Raut', 'Vijay', 'Male', '4th year', 'upload/WhatsApp Image 2025-06-24 at 13.55.10_29ab7c8e.jpg'),
(416, 'f', '4th Year Representative', 'Vikas Sena', 'Megha', 'Mahajan', 'Sunita', 'Female', '4th year', 'upload/WhatsApp Image 2025-06-24 at 13.51.18_3d847c84.jpg'),
(128, 'b', 'Vice-Governor', 'Div (B)', 'Bhau', 'Shinde', '', 'Male', '3rd year', 'upload/joneil.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `history_id` int(11) NOT NULL,
  `data` varchar(30) NOT NULL,
  `action` varchar(50) NOT NULL,
  `date` varchar(20) NOT NULL,
  `user` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `data`, `action`, `date`, `user`) VALUES
(568, 'john kevin lorayna', 'Login', '2012-11-08 09:46:23', 'admin'),
(567, 'john kevin lorayna', 'Logout', '2012-11-08 09:45:59', 'admin'),
(566, 'john kevin lorayna', 'Login', '2012-11-08 09:44:41', 'admin'),
(565, 'john kevin lorayna', 'Login', '2012-11-03 20:24:08', 'admin'),
(564, 'Achilles Palma', 'Deleted Voter', '10/25/2012 11:1:39', 'admin'),
(563, 'john kevin lorayna', 'Login', '2012-10-25 10:48:40', 'admin'),
(569, 'john kevin lorayna', 'Login', '2025-06-22 14:09:02', 'admin'),
(570, ' ', 'Logout', '2025-06-22 14:31:15', ''),
(571, 'john kevin lorayna', 'Login', '2025-06-22 14:31:20', 'admin'),
(572, 'john kevin lorayna', 'Login', '2025-06-22 14:44:45', 'admin'),
(573, 'john kevin lorayna', 'Login', '2025-06-22 14:45:45', 'admin'),
(574, 'Achilles Palma', 'Deleted Candidate', '6/22/2025 14:45:51', 'Admin'),
(575, 'Sherwin Laylon', 'Deleted Candidate', '6/22/2025 14:45:51', 'Admin'),
(576, 'Cristian Sausa', 'Deleted Candidate', '6/22/2025 14:46:1', 'Admin'),
(577, 'Bhau ', 'Edit Candidate', '2025-06-22 14:47:13', 'admin'),
(578, 'Bhau Shinde', 'Edit Candidate', '2025-06-22 14:47:35', 'admin'),
(579, 'Raphael Victor Combate', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(580, 'Mary Ver Pamposa', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(581, 'Rowan Jennele Villamor', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(582, 'Jeza Marie Telmoso', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(583, 'Ailyn Tanaleon', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(584, 'Golda Nepomuceno', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(585, 'Veronica Bianayco', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(586, 'May Mendoza', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(587, 'Jorgielyn Serfino', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(588, 'Brian Paul Sablan', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(589, 'Michelle De Asis', 'Deleted Candidate', '6/22/2025 14:47:42', 'Admin'),
(590, 'Denmark Tabiolo', 'Deleted Candidate', '6/22/2025 14:48:29', 'Admin'),
(591, 'Freddie Clavel', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(592, 'jed Vargas', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(593, 'kzille naynay', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(594, 'jetro Vargas', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(595, 'marven actub', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(596, 'Dean Martin Tingson', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(597, 'Stephanie Villanueva', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(598, 'Jerson Vargas', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(599, 'Anton Victor Jacobo', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(600, 'Cristine Yanson', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(601, 'Anamae Alquizar', 'Deleted Candidate', '6/22/2025 14:48:35', 'Admin'),
(602, 'Thea Marie Soberano', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(603, 'Jorgielyn Serfino', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(604, 'Charito Puray', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(605, 'Honeylee Magbanua', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(606, 'Alan De La Torre', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(607, 'Victor Jacobo', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(608, 'Jomar Pabuaya', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(609, 'Cristine Yanson', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(610, 'Michael Jomero', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(611, 'Fernrose Olarte', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(612, 'Achilles Palma', 'Deleted Candidate', '6/22/2025 14:49:5', 'Admin'),
(613, 'Hugh Jackman', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(614, 'Zac Efron', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(615, 'Alex Pettyfer', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(616, 'Joanna Bustillo', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(617, 'Lovely Mae Jurilla', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(618, 'Ailyn Barameda', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(619, 'Michael Cachero', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(620, 'Louise Po', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(621, 'Al Mario Small', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(622, 'Eunice Bautista', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(623, 'Lonida Delez', 'Deleted Candidate', '6/22/2025 14:49:36', 'Admin'),
(624, 'Christian Sausa', 'Deleted Candidate', '6/22/2025 14:50:4', 'Admin'),
(625, 'Gerald Anderson', 'Deleted Candidate', '6/22/2025 14:50:11', 'Admin'),
(626, 'Mark dominic', 'Deleted Candidate', '6/22/2025 14:50:16', 'Admin'),
(627, 'john kevin lorayna', 'Login', '2025-06-22 14:56:52', 'admin'),
(628, 'Aarav Patil', 'Edit Candidate', '2025-06-22 14:58:24', 'admin'),
(629, 'Bhau Shinde', 'Edit Candidate', '2025-06-22 14:58:47', 'admin'),
(630, 'Bhau Shinde', 'Edit Candidate', '2025-06-22 14:59:02', 'admin'),
(631, 'Sneha Deshmukh', 'Edit Candidate', '2025-06-22 14:59:06', 'admin'),
(632, 'Sneha Deshmukh', 'Edit Candidate', '2025-06-22 14:59:28', 'admin'),
(633, 'Vaibhav  m', 'Login', '2025-06-22 15:04:57', 'Admin'),
(634, 'Aarav Patil', 'Edit Candidate', '2025-06-22 15:40:41', 'Admin'),
(635, 'Vaibhav  m', 'Login', '2025-06-22 15:41:28', 'Admin'),
(636, 'Vaibhav  m', 'Login', '2025-06-22 18:22:26', 'Admin'),
(637, 'om  k', 'Added Voter', '6/22/2025 18:22:33', 'Admin'),
(638, 'Vaibhav  m', 'Login', '2025-06-22 18:29:11', 'Admin'),
(639, 'Vaibhav  m', 'Logout', '2025-06-22 18:29:31', 'Admin'),
(640, 'Vaibhav  m', 'Login', '2025-06-23 06:31:45', 'Admin'),
(641, 'john kevin lorayna', 'Login', '2025-06-23 06:34:00', 'admin'),
(642, 'john kevin lorayna', 'Login', '2025-06-23 06:39:51', 'admin'),
(643, 'john kevin lorayna', 'Login', '2025-06-23 07:15:39', 'admin'),
(644, 'john kevin lorayna', 'Login', '2025-06-23 10:57:53', 'admin'),
(645, 'john kevin lorayna', 'Logout', '2025-06-23 13:11:53', 'admin'),
(646, 'Vaibhav  m', 'Login', '2025-06-23 13:17:11', 'Admin'),
(647, 'Vaibhav  m', 'Logout', '2025-06-24 11:04:21', 'Admin'),
(648, 'Vaibhav  m', 'Login', '2025-06-24 11:05:37', 'Admin'),
(649, 'Vaibhav  m', 'Login', '2025-06-24 11:06:20', 'Admin'),
(650, 'adii L', 'Edit Candidate', '2025-06-24 13:44:37', 'Admin'),
(651, 'Sneha Deshmukh', 'Edit Candidate', '2025-06-24 13:45:47', 'Admin'),
(652, 'adii L', 'Edit Candidate', '2025-06-24 13:45:55', 'Admin'),
(653, 'nick k', 'Edit Candidate', '2025-06-24 13:46:24', 'Admin'),
(654, 'adii Lavhrale', 'Edit Candidate', '2025-06-24 13:48:48', 'Admin'),
(655, 'nick k', 'Edit Candidate', '2025-06-24 13:48:55', 'Admin'),
(656, 'Aarav Patil', 'Edit Candidate', '2025-06-24 13:55:38', 'Admin'),
(657, 'Sneha Deshmukh', 'Edit Candidate', '2025-06-24 13:55:47', 'Admin'),
(658, 'Omkar Sawant', 'Edit Candidate', '2025-06-24 13:56:00', 'Admin'),
(659, 'Prajakta Jadhav', 'Edit Candidate', '2025-06-24 13:56:06', 'Admin'),
(660, 'Swapnil Shinde', 'Edit Candidate', '2025-06-24 13:56:34', 'Admin'),
(661, 'Tanvi Kadam', 'Edit Candidate', '2025-06-24 13:56:45', 'Admin'),
(662, 'Sachin Naik', 'Edit Candidate', '2025-06-24 13:56:56', 'Admin'),
(663, 'Riya Pawar', 'Edit Candidate', '2025-06-24 13:57:06', 'Admin'),
(664, 'Kunal Gaikwad', 'Edit Candidate', '2025-06-24 13:57:18', 'Admin'),
(665, 'om  Thorat', 'Edit Candidate', '2025-06-24 13:57:53', 'Admin'),
(666, 'Siddharth Londhe', 'Edit Candidate', '2025-06-24 13:58:03', 'Admin'),
(667, 'anish Chavan', 'Edit Candidate', '2025-06-24 13:58:26', 'Admin'),
(668, 'Mayur Bhosale', 'Edit Candidate', '2025-06-24 13:58:42', 'Admin'),
(669, 'Aishwarya Salunkhe', 'Edit Candidate', '2025-06-24 13:58:49', 'Admin'),
(670, 'Yash Raut', 'Edit Candidate', '2025-06-24 13:58:56', 'Admin'),
(671, 'Megha Mahajan', 'Edit Candidate', '2025-06-24 13:59:03', 'Admin'),
(672, 'john kevin lorayna', 'Login', '2025-06-24 13:59:58', 'admin'),
(673, ' ', 'Logout', '2025-06-24 15:04:02', ''),
(674, 'Vaibhav  m', 'Login', '2025-06-24 15:20:51', 'Admin'),
(675, 'adii Lavhrale', 'Edit Candidate', '2025-06-25 10:26:31', 'Admin'),
(676, 'Shrinath  Pujari', 'Added Voter', '6/25/2025 10:32:39', 'Admin'),
(677, 'Nikhil Kokate', 'Edit Candidate', '2025-06-25 10:34:36', 'Admin'),
(678, ' ', 'Logout', '2025-06-25 10:37:51', ''),
(679, 'Vaibhav  m', 'Login', '2025-06-25 10:37:57', 'Admin'),
(680, 'anish Chavan', 'Edit Candidate', '2025-06-25 10:38:25', 'Admin'),
(681, 'Vaibhav  m', 'Login', '2025-06-25 10:39:35', 'Admin'),
(682, 'john kevin lorayna', 'Login', '2025-06-25 10:42:56', 'admin'),
(683, ' ', 'Logout', '2025-06-25 10:49:15', ''),
(684, 'Vaibhav  m', 'Login', '2025-06-25 10:49:20', 'Admin'),
(685, 'Vaibhav  m', 'Logout', '2025-06-25 10:59:59', 'Admin'),
(686, 'Vaibhav  m', 'Login', '2025-06-25 11:00:03', 'Admin'),
(687, 'Vaibhav  m', 'Logout', '2025-06-25 11:01:57', 'Admin'),
(688, 'Vaibhav  m', 'Login', '2025-06-25 11:02:03', 'Admin'),
(689, 'Vaibhav  m', 'Login', '2025-06-25 11:49:58', 'Admin'),
(690, 'Vaibhav  m', 'Login', '2025-06-25 11:54:19', 'Admin'),
(691, 'Vaibhav  m', 'Login', '2025-06-25 11:58:01', 'Admin'),
(692, 'Vaibhav  m', 'Login', '2025-07-11 21:23:34', 'Admin'),
(693, 'Vaibhav  m', 'Login', '2025-07-11 21:26:05', 'Admin'),
(694, 'Vaibhav  m', 'Logout', '2025-07-12 19:55:39', 'Admin'),
(695, 'Vaibhav  m', 'Login', '2025-07-16 15:41:57', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_id` int(11) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `User_Type` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_id`, `FirstName`, `LastName`, `UserName`, `Password`, `User_Type`) VALUES
(2, 'adii', 'l', 'admin', 'admin', 'admin'),
(4, 'Vaibhav ', 'm', 'Vaibhav', '1234', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `VoterID` int(11) NOT NULL,
  `FirstName` varchar(150) NOT NULL,
  `LastName` varchar(150) NOT NULL,
  `MiddleName` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Year` varchar(100) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`VoterID`, `FirstName`, `LastName`, `MiddleName`, `Username`, `Password`, `Year`, `Status`) VALUES
(24, 'Maricon', 'Itona', 'M.', '20100333', 'concon', '1st year', 'Voted'),
(23, 'Raphael Victor', 'Combate', 'R.', '20100222', 'raprap', '1st year', 'Unvoted'),
(17, 'May', 'Mendoza', 'Alvijos', '20100323', 'may', '1st year', 'Unvoted'),
(18, 'Golda', 'Nepomuceno', 'Molentin', '20100316', 'golda', '1st year', 'Voted'),
(19, 'Shiera Mae', 'Tuting', 'Terer', '20100968', 'shiera', '3rd year', 'Unvoted'),
(20, 'Mary Ver', 'Libo-on', 'M', '20100381', 'mary', '1st year', 'Unvoted'),
(21, 'John Kevin', 'Lorayna', 'Amos', '20100412', 'kevin', '1st year', 'Unvoted'),
(22, 'Denmark', 'Tabiolo', 'R', '20100111', 'denmark', '1st year', 'Voted'),
(16, 'Sherwin', 'Laylon', 'Delicana', '20100349', 'zac', '3rd year', 'Unvoted'),
(25, 'Joneil', 'Constantino', 'N.', '20100333', 'joneil', '3rd year', 'Unvoted'),
(26, 'Charito', 'Puray', 'N.', '20100444', 'char', '3rd year', 'Voted'),
(27, 'Honeylee', 'Magbanua', 'M.', '20100555', 'honey', '3rd year', 'Unvoted'),
(28, 'Jonald', 'Pamposa', 'T.', '20100666', 'jonald', '2nd year', 'Unvoted'),
(29, 'Michelle', 'De Asis', 'R.', '20100777', 'mich', '1st year', 'Unvoted'),
(30, 'Rowan', 'Villamor', 'O.', '20100888', 'rowan', '1st year', 'Unvoted'),
(31, 'Fernrose', 'Olarte', 'P.', '20100123', 'fern', '3rd year', 'Unvoted'),
(32, 'Ryan', 'Malbata-an', 'P.', '20100246', 'ryan', '2nd year', 'Unvoted'),
(33, 'Ariane Mae', 'Ferrer', 'I.', '20100395', 'mae', '2nd year', 'Voted'),
(34, 'Jamilah', 'Lomot', 'Y.', '20100567', 'jam', '2nd year', 'Voted'),
(35, 'Lonida', 'Delez', 'P.', '20100678', 'kring', '4th year', 'Unvoted'),
(36, 'Allan', 'De La Torre', 'O.', '20100876', 'allan', '4th year', 'Voted'),
(37, 'Lovelyn', 'Jurilla', 'D.', '20100126', 'lovelyn', '4th year', 'Unvoted'),
(38, 'Stephanie', 'Villanueva', 'T.', '20100986', 'teph', '2nd year', 'Unvoted'),
(39, 'Zac', 'Efron', 'O.', '20100945', 'zac', '4th year', 'Unvoted'),
(40, 'Hugh', 'Jackman', 'Y.', '20100786', 'hugh', '4th year', 'Unvoted'),
(41, 'Gerald', 'Anderson', 'O.', '20100865', 'gerald', '4th year', 'Voted'),
(42, 'Alex', 'Pettyfer', 'Z.', '20100432', 'alex', '4th year', 'Voted'),
(44, 'Cristine', 'Yanson', 'P.', '20100764', 'cris', '3rd year', 'Voted'),
(45, 'Jomar', 'Pabuaya', 'U.', '20100561', 'jomar', '3rd year', 'Unvoted'),
(48, 'Anamae', 'Alquizar', 'dela Cruz', '20100113', 'sarge', '2nd year', 'Voted'),
(51, 'Amit', 'Jadhav', 'S.', '20210051', 'amit123', '1st year', 'Voted'),
(52, 'Sneha', 'Patil', 'R.', '20210052', 'sneha123', '2nd year', 'Unvoted'),
(53, 'Rahul', 'Deshmukh', 'A.', '20210053', 'rahul123', '3rd year', 'Unvoted'),
(54, 'Pooja', 'Pawar', 'V.', '20210054', 'pooja123', '4th year', 'Voted'),
(55, 'Ajay', 'Shinde', 'T.', '20210055', 'ajay123', '1st year', 'Voted'),
(56, 'Kavita', 'More', 'K.', '20210056', 'kavita123', '2nd year', 'Unvoted'),
(57, 'Sagar', 'Chavan', 'L.', '20210057', 'sagar123', '3rd year', 'Voted'),
(58, 'Neha', 'Bhosale', 'M.', '20210058', 'neha123', '4th year', 'Unvoted'),
(59, 'Ramesh', 'Gaikwad', 'P.', '20210059', 'ramesh123', '1st year', 'Unvoted'),
(60, 'Anjali', 'Sawant', 'Y.', '20210060', 'anjali123', '2nd year', 'Voted'),
(61, 'Mahesh', 'Salunkhe', 'N.', '20210061', 'mahesh123', '3rd year', 'Unvoted'),
(62, 'Komal', 'Thorat', 'B.', '20210062', 'komal123', '4th year', 'Unvoted'),
(63, 'Nilesh', 'Dabholkar', 'Q.', '20210063', 'nilesh123', '1st year', 'Unvoted'),
(64, 'Reshma', 'Kamble', 'H.', '20210064', 'reshma123', '2nd year', 'Unvoted'),
(65, 'Vishal', 'Nalawade', 'W.', '20210065', 'vishal123', '3rd year', 'Unvoted'),
(66, 'Prachi', 'Londhe', 'C.', '20210066', 'prachi123', '4th year', 'Unvoted'),
(67, 'Santosh', 'Mane', 'E.', '20210067', 'santosh123', '1st year', 'Unvoted'),
(68, 'Dipali', 'Bhagat', 'D.', '20210068', 'dipali123', '2nd year', 'Voted'),
(69, 'Ganesh', 'Kolhe', 'Z.', '20210069', 'ganesh123', '3rd year', 'Voted'),
(70, 'Meena', 'Zende', 'U.', '20210070', 'meena123', '4th year', 'Unvoted'),
(71, 'om ', 'k', 'n', 'om ', '1234', '3rd year', 'Voted'),
(72, 'Shrinath ', 'Pujari', 'Subhash', 'Shree ', '78878787877', '3rd year', 'Unvoted');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `ID` int(11) NOT NULL,
  `CandidateID` int(11) NOT NULL,
  `votes` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`ID`, `CandidateID`, `votes`) VALUES
(205, 0, 0),
(204, 0, 0),
(203, 153, 0),
(202, 129, 0),
(201, 95, 0),
(206, 95, 0),
(207, 129, 0),
(208, 101, 0),
(209, 103, 0),
(210, 136, 0),
(211, 95, 0),
(212, 129, 0),
(213, 101, 0),
(214, 103, 0),
(215, 136, 0),
(216, 95, 0),
(217, 128, 0),
(218, 184, 0),
(219, 183, 0),
(220, 180, 0),
(221, 95, 0),
(222, 128, 0),
(223, 180, 0),
(224, 177, 0),
(225, 178, 0),
(226, 301, 0),
(227, 303, 0),
(228, 186, 0),
(229, 182, 0),
(230, 176, 0),
(231, 301, 0),
(232, 128, 0),
(233, 414, 0),
(234, 413, 0),
(235, 415, 0),
(236, 301, 0),
(237, 303, 0),
(238, 402, 0),
(239, 301, 0),
(240, 128, 0),
(241, 407, 0),
(242, 301, 0),
(243, 303, 0),
(244, 408, 0),
(245, 302, 0),
(246, 128, 0),
(247, 401, 0),
(248, 301, 0),
(249, 303, 0),
(250, 404, 0),
(251, 302, 0),
(252, 303, 0),
(253, 408, 0),
(254, 302, 0),
(255, 303, 0),
(256, 408, 0),
(257, 302, 0),
(258, 128, 0),
(259, 407, 0),
(260, 301, 0),
(261, 128, 0),
(262, 412, 0),
(263, 302, 0),
(264, 128, 0),
(265, 416, 0),
(266, 302, 0),
(267, 303, 0),
(268, 402, 0),
(269, 301, 0),
(270, 303, 0),
(271, 408, 0),
(272, 302, 0),
(273, 303, 0),
(274, 402, 0),
(275, 301, 0),
(276, 128, 0),
(277, 405, 0),
(278, 301, 0),
(279, 128, 0),
(280, 412, 0),
(281, 302, 0),
(282, 303, 0),
(283, 409, 0),
(284, 301, 0),
(285, 128, 0),
(286, 414, 0),
(287, 301, 0),
(288, 303, 0),
(289, 401, 0),
(290, 302, 0),
(291, 303, 0),
(292, 407, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`CandidateID`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_id`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`VoterID`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `CandidateID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=417;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=696;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `VoterID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=293;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
