	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container">
	     
		<a class="brand">
		<img src="images/mbes.png" width="60" height="60">
 	</a>
	<a class="brand">
	 <h2>mbes college of engineering ambajogai Voting System</h2>
	 <div class="mbes_nav"><font size="4" color="white">mbes college of engineering ambajogai</font></div>
 	</a>

	<?php include('head.php'); ?>
 
 
	</div>
	</div>
	</div>
	