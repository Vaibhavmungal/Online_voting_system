	  <hr>

      <footer>
        <div>
		<p>&nbsp;&nbsp;&nbsp;.x </p>
		</div>
      </footer>