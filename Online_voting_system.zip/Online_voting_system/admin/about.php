<h1><font color="gray">Online Voting System</font></h1>
</br>
<font color="#555">
<p>For college of engineering ambajogai</p>
</font>
</br>
<div id="accordion2" class="accordion">
<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapseOne" data-parent="#accordion2" data-toggle="collapse">vaibhav mungal </a>
</div>
<div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
<div class="accordion-inner"> 
<p><font color="gray">Position:&nbsp;Programmer</font></p>
<p><font color="gray">FirstName:&nbsp;vaibhav</font></p>
<p><font color="gray">LastName:&nbsp;mungal</font></p>
<p><font color="gray">Age:&nbsp;20</font></p>
<p><font color="gray">Address:&nbsp; ambajogai</font></p>
<p><font color="gray">Email:&nbsp;vaibhavmungal123@gmail.com</font></p>
<p><font color="gray">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></p>
<div class="user_image"><img src="project_member/kev.jpg" width="200" height="250"></div>
</div>
</div>
</div>




